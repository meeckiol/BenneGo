const { query, getClient } = require('../config/database');
const { AppError } = require('../middlewares/error.middleware');
const { calculateRoute, calculatePrice } = require('../services/pricing.service');
const payments = require('../services/payment.service');
const events = require('../services/order-events');

/**
 * Génère un numéro de commande unique
 */
const generateOrderNumber = () => {
  const year = new Date().getFullYear();
  const random = require('crypto').randomInt(0, 1000000).toString().padStart(6, '0');
  return `LT-${year}-${random}`;
};

/**
 * POST /api/orders/estimate
 * Estimateur de prix avant commande
 */
const estimatePrice = async (req, res, next) => {
  try {
    const {
      pickup_lat, pickup_lng,
      delivery_lat, delivery_lng,
      truck_type = 'simple_benne',
    } = req.body;

    const route = await calculateRoute(
      parseFloat(pickup_lat), parseFloat(pickup_lng),
      parseFloat(delivery_lat), parseFloat(delivery_lng)
    );

    const pricing = calculatePrice(route.distance_km, truck_type);

    res.json({
      distance_km: route.distance_km,
      duration_min: route.duration_min,
      ...pricing,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/orders
 * Créer une nouvelle commande
 */
const createOrder = async (req, res, next) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');

    const {
      pickup_lat, pickup_lng, pickup_address, pickup_contact,
      delivery_lat, delivery_lng, delivery_address, delivery_contact,
      material_type_id, quantity_m3, material_description,
      truck_type = 'simple_benne', notes,
    } = req.body;

    // Calculer la distance et le prix
    const route = await calculateRoute(
      parseFloat(pickup_lat), parseFloat(pickup_lng),
      parseFloat(delivery_lat), parseFloat(delivery_lng)
    );
    const pricing = calculatePrice(route.distance_km, truck_type);

    const orderNumber = generateOrderNumber();

    const result = await client.query(
      `INSERT INTO orders (
        order_number, client_id,
        pickup_lat, pickup_lng, pickup_address, pickup_contact,
        delivery_lat, delivery_lng, delivery_address, delivery_contact,
        material_type_id, quantity_m3, material_description,
        distance_km, price_per_km,
        total_amount, commission_amount, driver_amount,
        notes, status, payment_status
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,'awaiting_payment','unpaid')
      RETURNING *`,
      [
        orderNumber, req.user.id,
        pickup_lat, pickup_lng, pickup_address, pickup_contact || null,
        delivery_lat, delivery_lng, delivery_address, delivery_contact || null,
        material_type_id || null, quantity_m3, material_description || null,
        route.distance_km, pricing.price_per_km,
        pricing.total_amount, pricing.commission_amount, pricing.driver_amount,
        notes || null,
      ]
    );

    await client.query('COMMIT');

    const order = result.rows[0];

    // Les chauffeurs ne voient la commande qu'une fois le paiement bloqué en séquestre.

    res.status(201).json({
      message: 'Commande créée. Procédez au paiement pour la publier aux chauffeurs.',
      order,
      next_step: 'payment',
    });
  } catch (error) {
    await client.query('ROLLBACK');
    next(error);
  } finally {
    client.release();
  }
};

/**
 * GET /api/orders
 * Liste des commandes (filtrée selon le rôle)
 */
const getOrders = async (req, res, next) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let whereClause = '';
    const params = [];
    let paramIdx = 1;

    if (req.user.role === 'client') {
      whereClause = `WHERE o.client_id = $${paramIdx++}`;
      params.push(req.user.id);
    } else if (req.user.role === 'driver') {
      whereClause = `WHERE (o.driver_id = $${paramIdx++} OR (o.status = 'pending' AND o.payment_status = 'escrow_held'))`;
      params.push(req.user.id);
    }

    if (status) {
      whereClause += whereClause ? ` AND o.status = $${paramIdx++}` : `WHERE o.status = $${paramIdx++}`;
      params.push(status);
    }

    const countResult = await query(
      `SELECT COUNT(*) FROM orders o ${whereClause}`,
      params
    );

    const result = await query(
      `SELECT o.*,
              u_client.full_name AS client_name, u_client.phone AS client_phone,
              u_driver.full_name AS driver_name, u_driver.phone AS driver_phone,
              mt.name AS material_name
       FROM orders o
       LEFT JOIN users u_client ON u_client.id = o.client_id
       LEFT JOIN users u_driver ON u_driver.id = o.driver_id
       LEFT JOIN material_types mt ON mt.id = o.material_type_id
       ${whereClause}
       ORDER BY o.created_at DESC
       LIMIT $${paramIdx++} OFFSET $${paramIdx++}`,
      [...params, parseInt(limit), offset]
    );

    res.json({
      orders: result.rows,
      pagination: {
        total: parseInt(countResult.rows[0].count),
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(parseInt(countResult.rows[0].count) / parseInt(limit)),
      },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * GET /api/orders/:id
 * Détail d'une commande
 */
const getOrder = async (req, res, next) => {
  try {
    const result = await query(
      `SELECT o.*,
              u_client.full_name AS client_name, u_client.phone AS client_phone,
              u_driver.full_name AS driver_name, u_driver.phone AS driver_phone,
              dp.truck_type, dp.truck_plate, dp.rating AS driver_rating_avg, dp.rating_count AS driver_rating_count,
              mt.name AS material_name
       FROM orders o
       LEFT JOIN users u_client ON u_client.id = o.client_id
       LEFT JOIN users u_driver ON u_driver.id = o.driver_id
       LEFT JOIN driver_profiles dp ON dp.user_id = o.driver_id
       LEFT JOIN material_types mt ON mt.id = o.material_type_id
       WHERE o.id = $1`,
      [req.params.id]
    );

    if (!result.rows.length) {
      throw new AppError('Commande introuvable', 404);
    }

    const order = result.rows[0];

    // Vérifier les droits d'accès
    if (req.user.role === 'client' && order.client_id !== req.user.id) {
      throw new AppError('Accès refusé', 403);
    }
    if (req.user.role === 'driver' && order.driver_id !== req.user.id
      && !(order.status === 'pending' && order.payment_status === 'escrow_held')) {
      throw new AppError('Accès refusé', 403);
    }

    res.json({ order });
  } catch (error) {
    next(error);
  }
};

/**
 * PATCH /api/orders/:id/accept
 * Chauffeur accepte une commande (uniquement si le paiement est bloqué en séquestre)
 */
const acceptOrder = async (req, res, next) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');

    const result = await client.query(
      'SELECT * FROM orders WHERE id = $1 FOR UPDATE',
      [req.params.id]
    );
    if (!result.rows.length) throw new AppError('Commande introuvable', 404);
    const order = result.rows[0];

    if (order.status !== 'pending' || order.payment_status !== 'escrow_held') {
      throw new AppError('Cette commande n\'est plus disponible', 409);
    }

    const driverResult = await client.query(
      'SELECT is_available, momo_number, momo_provider FROM driver_profiles WHERE user_id = $1 FOR UPDATE',
      [req.user.id]
    );
    const profile = driverResult.rows[0];
    if (!profile) throw new AppError('Complétez votre profil chauffeur avant d\'accepter une course', 400);
    if (!profile.momo_number || !profile.momo_provider) {
      throw new AppError('Renseignez votre numéro Mobile Money : il sert à vous verser votre part', 400);
    }
    if (!profile.is_available) {
      throw new AppError('Vous devez être en mode disponible pour accepter des courses', 400);
    }

    await client.query(
      `UPDATE orders SET driver_id = $1, status = 'accepted', accepted_at = NOW(), updated_at = NOW()
       WHERE id = $2`,
      [req.user.id, order.id]
    );
    await client.query('UPDATE driver_profiles SET is_available = false WHERE user_id = $1', [req.user.id]);
    await client.query('COMMIT');

    const io = req.app.get('io');
    if (io) {
      io.to(`client_${order.client_id}`).emit('order_accepted', {
        order_id: order.id,
        driver_id: req.user.id,
        driver_name: req.user.full_name,
      });
      events.notifyStatus(io, order, 'accepted');
      events.notifyOrderTaken(io, order.id);
    }

    res.json({ message: 'Commande acceptée avec succès' });
  } catch (error) {
    await client.query('ROLLBACK');
    next(error);
  } finally {
    client.release();
  }
};

/**
 * PATCH /api/orders/:id/status
 * Le chauffeur fait avancer la course. La validation finale appartient au client
 * (POST /api/orders/:id/confirm-delivery) — le chauffeur ne peut jamais "se valider" lui-même.
 */
const DRIVER_TRANSITIONS = {
  accepted: 'driver_en_route_pickup',
  driver_en_route_pickup: 'loading',
  loading: 'driver_en_route_delivery',
  driver_en_route_delivery: 'delivered',
};

const updateOrderStatus = async (req, res, next) => {
  const { status } = req.body;
  if (req.user.role !== 'driver') {
    return next(new AppError('Seul le chauffeur peut faire avancer la course. Le client confirme la réception via « Confirmer la réception ».', 403));
  }

  const db = await getClient();
  try {
    await db.query('BEGIN');
    const orderResult = await db.query('SELECT * FROM orders WHERE id = $1 FOR UPDATE', [req.params.id]);
    if (!orderResult.rows.length) throw new AppError('Commande introuvable', 404);
    const order = orderResult.rows[0];

    if (order.driver_id !== req.user.id) throw new AppError('Accès refusé', 403);
    if (order.payment_status !== 'escrow_held') throw new AppError('Paiement non sécurisé pour cette commande', 409);
    if (DRIVER_TRANSITIONS[order.status] !== status) {
      throw new AppError(`Transition de statut invalide: ${order.status} → ${status}`, 400);
    }

    const timestampColumns = {
      driver_en_route_pickup: 'pickup_at',
      delivered: 'delivered_at',
    };
    const tsColumn = timestampColumns[status];
    await db.query(
      tsColumn
        ? `UPDATE orders SET status = $1, ${tsColumn} = NOW(), updated_at = NOW() WHERE id = $2`
        : 'UPDATE orders SET status = $1, updated_at = NOW() WHERE id = $2',
      [status, order.id]
    );
    await db.query('COMMIT');

    const io = req.app.get('io');
    events.notifyStatus(io, order, status);
    if (status === 'delivered' && io) {
      io.to(`client_${order.client_id}`).emit('delivery_to_confirm', { order_id: order.id });
    }

    res.json({ message: `Statut mis à jour: ${status}` });
  } catch (error) {
    await db.query('ROLLBACK');
    next(error);
  } finally {
    db.release();
  }
};

/**
 * POST /api/orders/:id/confirm-delivery   (client)
 * Bouton « Confirmer la réception » : libère l'argent bloqué —
 * 10 % pour la plateforme, 90 % pour le chauffeur.
 */
const confirmDelivery = async (req, res, next) => {
  try {
    const result = await payments.confirmDelivery(req.params.id, req.user.id);
    const io = req.app.get('io');

    if (!result.alreadyDone && io) {
      events.notifyStatus(io, result.order, 'validated');
      io.to(`driver_${result.driverId}`).emit('order_validated', {
        order_id: result.orderId,
        driver_amount: result.order.driver_amount,
      });
    }

    res.json({
      message: 'Réception confirmée. Merci ! Le paiement est transmis au chauffeur.',
      commission_amount: Number(result.order.commission_amount),
      driver_amount: Number(result.order.driver_amount),
      payout: result.settlement.status,
      can_review: true,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/orders/:id/cancel   (client)
 * Avant paiement : simple annulation. Après paiement et tant qu'aucun chauffeur n'a accepté :
 * remboursement intégral.
 */
const cancelOrder = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM orders WHERE id = $1', [req.params.id]);
    if (!rows.length) throw new AppError('Commande introuvable', 404);
    const order = rows[0];
    if (order.client_id !== req.user.id) throw new AppError('Accès refusé', 403);

    if (order.status === 'awaiting_payment' && order.payment_status === 'unpaid') {
      const upd = await query(
        `UPDATE orders SET status = 'cancelled', cancelled_at = NOW(), cancellation_reason = $2, updated_at = NOW()
         WHERE id = $1 AND status = 'awaiting_payment' AND payment_status = 'unpaid'`,
        [order.id, req.body.reason || null]
      );
      if (!upd.rowCount) throw new AppError('Annulation impossible', 409);
      return res.json({ message: 'Commande annulée', refunded: false });
    }

    await payments.refundEscrow(order.id, { actor: req.user, reason: req.body.reason });
    events.notifyOrderTaken(req.app.get('io'), order.id);
    res.json({ message: 'Commande annulée et remboursée', refunded: true });
  } catch (error) {
    next(error);
  }
};

/**
 * GET /api/orders/:id/tracking
 * Dernière position + trajet parcouru (client propriétaire, chauffeur assigné ou admin)
 */
const getTracking = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT id, client_id, driver_id, status FROM orders WHERE id = $1', [req.params.id]);
    if (!rows.length) throw new AppError('Commande introuvable', 404);
    const order = rows[0];
    const allowed = req.user.role === 'admin'
      || (req.user.role === 'client' && order.client_id === req.user.id)
      || (req.user.role === 'driver' && order.driver_id === req.user.id);
    if (!allowed) throw new AppError('Accès refusé', 403);

    const points = await query(
      `SELECT lat, lng, recorded_at FROM (
         SELECT lat, lng, recorded_at FROM order_tracking WHERE order_id = $1
         ORDER BY recorded_at DESC LIMIT 300
       ) t ORDER BY recorded_at ASC`,
      [order.id]
    );
    const route = points.rows.map((p) => ({ lat: Number(p.lat), lng: Number(p.lng), recorded_at: p.recorded_at }));
    res.json({ order_id: order.id, status: order.status, route, last: route[route.length - 1] || null });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  estimatePrice,
  createOrder,
  getOrders,
  getOrder,
  acceptOrder,
  updateOrderStatus,
  confirmDelivery,
  cancelOrder,
  getTracking,
};
